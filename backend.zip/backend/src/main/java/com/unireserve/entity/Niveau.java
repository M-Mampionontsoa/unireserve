package com.unireserve.entity;

public enum Niveau {
    L1,
    L2,
    L3,
    M1,
    M2
}
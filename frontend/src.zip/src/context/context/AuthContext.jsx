import { createContext, useContext, useState, useCallback } from "react";
import { setAuthToken } from "../services/api";
import * as authService from "../services/authService";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null); // { nom, prenom, role }
  const [loading, setLoading] = useState(false);

  const loginUser = useCallback(async (credentials) => {
    setLoading(true);
    try {
      const data = await authService.login(credentials);
      setUser({ nom: data.nom, prenom: data.prenom, role: data.role });
      return data;
    } finally {
      setLoading(false);
    }
  }, []);

  const registerUser = useCallback(async (payload) => {
    setLoading(true);
    try {
      const data = await authService.register(payload);
      // si le backend connecte automatiquement apres inscription (token renvoye)
      if (data?.token) {
        setUser({ nom: data.nom, prenom: data.prenom, role: data.role });
      }
      return data;
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(() => {
    setAuthToken(null);
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider
      value={{ user, loading, loginUser, registerUser, logout, isAuthenticated: !!user }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth doit être utilisé dans un <AuthProvider>");
  return ctx;
}

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { LoginPage } from "../../components/auth/AuthPages";
import { useAuth } from "../../context/AuthContext";

export default function Login() {
  const { loginUser } = useAuth();
  const navigate = useNavigate();
  const [apiError, setApiError] = useState("");

  const handleSubmit = async (formData) => {
    setApiError("");
    try {
      await loginUser(formData);
      navigate("/salles"); // adapte vers ta route "Liste des salles"
    } catch (err) {
      const message =
        err.response?.status === 401
          ? "Email ou mot de passe incorrect."
          : "Une erreur est survenue, réessaie.";
      setApiError(message);
    }
  };

  const handleGoogleLogin = () => {
    // redirige vers l'endpoint OAuth2 Spring Security (Jour 3)
    window.location.href = `${import.meta.env.VITE_API_URL || "http://localhost:8080"}/oauth2/authorization/google`;
  };

  return (
    <>
      {apiError && (
        <div
          role="alert"
          style={{
            background: "#fdecee",
            color: "#b3273f",
            padding: "10px 16px",
            fontSize: 13.5,
            textAlign: "center",
          }}
        >
          {apiError}
        </div>
      )}
      <LoginPage
        onSubmit={handleSubmit}
        onSwitchToRegister={() => navigate("/inscription")}
        onGoogleLogin={handleGoogleLogin}
      />
    </>
  );
}

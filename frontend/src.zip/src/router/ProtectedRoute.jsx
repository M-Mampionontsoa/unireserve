import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

/**
 * Usage dans App.jsx :
 *
 *   <Route
 *     path="/admin/*"
 *     element={
 *       <ProtectedRoute rolesAutorises={["ADMIN"]}>
 *         <AdminDashboard />
 *       </ProtectedRoute>
 *     }
 *   />
 *
 * - Sans "rolesAutorises" : accessible a tout utilisateur connecte, peu importe le role.
 * - Avec "rolesAutorises" : accessible seulement aux roles listes.
 */
export default function ProtectedRoute({ children, rolesAutorises }) {
  const { user, isAuthenticated, loading } = useAuth();

  if (loading) {
    return null; // ou un petit spinner si tu en as un
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (rolesAutorises && !rolesAutorises.includes(user?.role)) {
    return <Navigate to="/" replace />;
  }

  return children;
}

import api, { setAuthToken } from "./api";

/**
 * IMPORTANT : adapte les noms de champs ci-dessous à ceux de tes DTO
 * backend (RegisterRequest / LoginRequest) si tu les as nommés autrement.
 */

export async function register({
  name,
  firstName,
  username,
  email,
  password,
  role,
}) {
  const { data } = await api.post("/signin", {
    name,
    firstName,
    username,
    email,
    password,
    role,
  });
  return data; // attendu : { token, nom, prenom, role }
}

export async function login({ email, password }) {
  const { data } = await api.post("/login", { email, motDePasse });
  if (data?.token) setAuthToken(data.token);
  return data; // attendu : { token, nom, prenom, role }
}

export function logout() {
  setAuthToken(null);
}
